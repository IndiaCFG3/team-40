from flask import Flask
from src.config import app_config
from src.model import db
import os
from src.views.mobiliser_view import  mobiliser_operations as mobiliser_operations_blueprint

def create_app(env_name):
    """
    Create app
    """
    # app initilization
    app = Flask(__name__)
    app.config.from_object(app_config[env_name])
    db.init_app(app)
    app.register_blueprint(mobiliser_operations_blueprint, url_prefix="/cfg/v1/mobiliser")


    @app.route("/ping", methods=["GET"])
    def index():
        return "Congratulations Gyanish! Your service is up and running"


    return app
