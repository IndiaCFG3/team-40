from marshmallow import fields, Schema
import datetime
from . import db

class OperationalManagerModel(db.Model):
    __tablename__ = 'op_manager_table'
    
    op_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    op_name = db.Column(db.String(128))
    op_email = db.Column(db.String(50))
    op_location = db.Column(db.String(10))
    op_password = db.Column(db.String(10))


    def __init__(self, user):

        self.op_id = user['op_id']
        self.op_name = user['op_name']
        self.op_email = user['op_email']
        self.op_location = user['op_location']
        self.op_password = user['op_password']

    def save(self):
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def getOperationalManager(id):
        return OperationalManagerModel.query.get(id)

    @staticmethod
    def getAllgetOperationalManager():
        return OperationalManagerModel.query.all()

    # check if id is already present in db
    @staticmethod
    def checkUserId(op_id):
        return OperationalManagerModel.query.filter_by(op_id = op_id).first()
    
    #delete user if user_id is present in db
    @staticmethod
    def deleteUser(op_id):
        return OperationalManagerModel.query.filter(op_id==op_id).delete()

    
class OperationalManagerSchema(Schema):

    op_id = fields.Integer()
    op_name = fields.Str()
    op_email = fields.Str()
    op_location = fields.Str()
    op_password = fields.Str()
    