from marshmallow import fields, Schema
import datetime
from . import db

class CentersModel(db.Model):
    __tablename__ = 'centers_table'
    
    cen_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cen_name = db.Column(db.String(128))
    cen_location = db.Column(db.String(10))


    def __init__(self, user):

        self.cen_id = user['cen_id']
        self.cen_name = user['cen_name']
        self.cen_location = user['cen_location']

    def save(self):
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def getcenterById(id):
        return CentersModel.query.get(id)

    @staticmethod
    def getAllCenters():
        return CentersModel.query.all()
    
    

    
class CentersSchema(Schema):

    cen_id = fields.Integer()
    cen_name = fields.Str()
    cen_location = fields.Str()
    