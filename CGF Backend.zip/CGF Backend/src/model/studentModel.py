from marshmallow import fields, Schema
import datetime
from . import db

class StudentModel(db.Model):
    __tablename__ = 'student_table'
    
    s_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    s_name = db.Column(db.String(128))
    s_email = db.Column(db.String(50))
    s_gender = db.Column(db.String(10))
    s_age = db.Column(db.String(10))
    s_interest = db.Column(db.String(10))
    s_pno = db.Column(db.String(10))
    s_precourses = db.Column(db.String(10))



    def __init__(self, user):

        self.s_id = user['s_id']
        self.s_name = user['s_name']
        self.s_email = user['s_email']
        self.s_gender = user['s_gender']
        self.s_age = user['s_age']
        self.s_interest = user['s_interest']
        self.s_pno = user['s_pno']
        self.s_precourses = user['s_precourses']


    def save(self):
        db.session.add(self)
        db.session.commit()



    
class StudentSchema(Schema):

    s_id = fields.Integer()
    s_name = fields.Str()
    s_email = fields.Str()
    s_gender = fields.Str()
    s_pno = fields.Str()
    s_age = fields.Str()
    s_interest = fields.Str()
    s_precourses = fields.Str()
    