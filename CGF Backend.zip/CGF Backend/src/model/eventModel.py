from marshmallow import fields, Schema
import datetime
from . import db

class EventModel(db.Model):
    __tablename__ = 'event_table'
    
    eve_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    eve_location = db.Column(db.String(128))


    def __init__(self, user):

        self.eve_id = user['eve_id']
        self.eve_location = user['eve_location']

    def save(self):
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def getEventById(id):
        return EventModel.query.get(id)

    @staticmethod
    def getAllEvent():
        return EventModel.query.all()

    # check if id is already present in db
    @staticmethod
    def checkEventId(op_id):
        return EventModel.query.filter_by(op_id = op_id).first()
    
class EventSchema(Schema):

    eve_id = fields.Integer()
    eve_location = fields.Str()
    