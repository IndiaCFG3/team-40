from marshmallow import fields, Schema
import datetime
from . import db
from .centersModel import CentersModel
from .eventModel import EventModel


class MobiliserModel(db.Model):
    __tablename__ = 'mobiliser_table'
    
    cen_id = db.Column(db.Integer, db.ForeignKey(CentersModel.cen_id))
    mob_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    mob_name = db.Column(db.String(128))
    mob_email = db.Column(db.String(50))
    mob_pass = db.Column(db.String(10))
    mob_pno = db.Column(db.String(10))
    op_id = db.Column(db.String(10))
    eve_id = db.Column(db.Integer, db.ForeignKey(EventModel.eve_id))


    def __init__(self, user):

        self.cen_id = user['cen_id']
        self.mob_id = user['mob_id']
        self.mob_name = user['mob_name']
        self.mob_email = user['mob_email']
        self.mob_pass = user['mob_pass']
        self.mob_pno = user['mob_pno']
        self.op_id = user['op_id']
        self.eve_id = user['eve_id']

    @staticmethod
    def getItem(id):
        return MobiliserModel.query.get(id)

    def save(self):
        db.session.add(self)
        db.session.commit()

    @staticmethod
    def getAllItems():
        return MobiliserModel.query.all()


    
class MobiliserSchema(Schema):

    cen_id = fields.Integer()
    eve_id = fields.Integer()
    mob_name = fields.Str()
    mob_email = fields.Str()
    mob_id = fields.Integer()
    mob_pno = fields.Str()
    op_id = fields.Integer()
    mob_pass = fields.Str()
    