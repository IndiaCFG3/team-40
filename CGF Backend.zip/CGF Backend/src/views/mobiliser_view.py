from flask import request, Response, Blueprint, jsonify
import os, sys
sys.path.append(os.path.abspath("./src/"))

from src.model.operationalManagerModel import OperationalManagerModel,OperationalManagerSchema
from src.model.MobiliserModel import MobiliserModel,MobiliserSchema
from src.model.centersModel import CentersModel, CentersSchema
from src.model.eventModel import EventModel,EventSchema
from src.model.studentModel import StudentModel,StudentSchema
from src.util.service_util import custom_response
from sqlalchemy import create_engine
import json

"""BluePrint"""
mobiliser_operations = Blueprint("mobiliser_operations", __name__)

"""Schemas"""
mobiliser_schema = MobiliserSchema()


"""Get All Mobilisers (API) """

@mobiliser_operations.route("/all", methods=["GET"])
def get_all_mobilisers():
    items = MobiliserModel.getAllItems()
    result = mobiliser_schema.dump(items, many=True).data
    return custom_response({"response": result}, 201)



@mobiliser_operations.route("/<string:item_id>", methods=["GET"])
def get_mobiliser_id(item_id):
    item = MobiliserModel.getItem(item_id)
    if not item:
        return custom_response({"error": "Mobiliser not found"}, 404)
    result = mobiliser_schema.dump(item).data
    return custom_response({"response":result}, 200)

@mobiliser_operations.route("/add", methods=["POST"])
def add_mobiliser():
    req = request.get_json()
    data, error = mobiliser_schema.load(req)
    if error:
        return custom_response(error, 500)
    mobiliser_data = MobiliserModel(data)
    mobiliser_data.save()
    return custom_response(
        {
            "response": {
                "message": "Mobiliser details added Successfully"
            }
        },
        201,
    )

