import os, sys
from src import create_app
from flask_cors import CORS
from sqlalchemy import create_engine
from flask_mail import Mail, Message


os.environ['DATABASE_URL'] = "postgres://postgres:Gyanish@4150@localhost:5432/cfg_db" 
os.environ['FLASK_ENV'] = "development"

env_name = os.getenv('FLASK_ENV')
app = create_app(env_name)
# mail = Mail(app)
CORS(app)

"""
Code for deleting all tables and migrations folder

"""

# engine = create_engine(os.getenv('DATABASE_URL'))
# tables = engine.table_names()

# for table in tables:
#     print("dropping table "+str(table))
#     engine.execute("drop table "+table+" cascade")


# """Creation of tables automatically"""

# os.system("python manage.py db init")
# os.system("python manage.py db migrate")
# os.system("python manage.py db upgrade")

# engine.dispose()



"""MAIN FUNCTION"""

if __name__ == '__main__':
    port = os.getenv('PORT')
    app.run(host="0.0.0.0", port=port)