import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {TableModule} from 'primeng/table';


@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private httpClient: HttpClient) { }

  getAllMobilisersURL = "";
  addMobiliserURL = "";
  getMobiliserByIdURL = "";

  mob_id;

  getAllMobilisers()
  {

    let obj = [
      {id:1,name:"ABC"},
      {id:2,name:"XYZ"},
      {id:3,name:"MNO"},
      {id:4,name:"ALK"},
      {id:5,name:"ASJ"},

    ]

    // return this.httpClient.get<any>(this.getAllMobilisersURL);
    return obj;
  }

  addMobiliser(payLoad)
  {
    let obj = [
      {id:1,name:"ABC"},
      {id:2,name:"XYZ"},
      {id:3,name:"MNO"},
      {id:4,name:"ALK"},
      {id:5,name:"ASJ"},

    ]
    let obj_new:any;
    obj_new["id"] = payLoad.mob_id;
    obj_new["name"] = payLoad.mob_name;
    obj.push(obj_new);

    return obj;

    // return this.httpClient.get<any>(this.getAllMobilisersURL);
  }

  //get mobiliser byId
  getMobiliserById(id)
  {

    let obj = { "cen_id": 2123, "mob_email": "test@getMaxListeners.com","mob_pno":880912219 ,"mob_id": "123HHA", "mob_pass": "askdjkdajs", "mob_name": "Mahesh Sinhania","op_id":"123alkks" }

    return obj;

    // return this.httpClient.get<any>(this.getMobiliserByIdURL+id);
  }
}
