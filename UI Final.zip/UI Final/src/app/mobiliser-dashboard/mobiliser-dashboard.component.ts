import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';

@Component({
  selector: 'app-mobiliser-dashboard',
  templateUrl: './mobiliser-dashboard.component.html',
  styleUrls: ['./mobiliser-dashboard.component.scss']
})
export class MobiliserDashboardComponent implements OnInit {

  constructor(private httpService : HttpService) { }
  students = [];
  events = [];
  cen_id;
  mob_email;
  mob_id;
  mob_name;
  mob_pno;
  op_id;

  ngOnInit(): void {

    if(this.httpService.mob_id)
    {
      this.getMobiliserDetails();
    }


    this.students=[
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"},
      {s_age:"12",s_email:"gyanish@gmail.com",s_gender:"male",s_id:"1",s_intrest:"game",s_name:"gyanish",s_pno:"12311424",s_precourses:"asdsaf"}
    ]

    this.events = [
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"},
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"},
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"},
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"},
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"},
    {eve_date:"10-02-2020", eve_location : "Bharuch", eve_name : "Webinar 1", eve_status : "Conduct", mob_id : "1234"}

    ]

  }

  getMobiliserDetails()
  {
    let result = this.httpService.getMobiliserById(this.httpService.mob_id);
    this.cen_id = result.cen_id;
    this.mob_email = result.mob_email;
    this.mob_id = result.mob_id;
    this.mob_name = result.mob_name;
    this.mob_pno = result.mob_pno;
    this.op_id = result.op_id;

  }

}
