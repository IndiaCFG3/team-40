import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MobiliserDashboardComponent } from './mobiliser-dashboard.component';

describe('MobiliserDashboardComponent', () => {
  let component: MobiliserDashboardComponent;
  let fixture: ComponentFixture<MobiliserDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MobiliserDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MobiliserDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
