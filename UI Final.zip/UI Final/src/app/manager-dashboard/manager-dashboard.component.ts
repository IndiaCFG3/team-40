import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-manager-dashboard',
  templateUrl: './manager-dashboard.component.html',
  styleUrls: ['./manager-dashboard.component.scss']
})
export class ManagerDashboardComponent implements OnInit {

  constructor(private httpService : HttpService, private router:Router,private formBuilder: FormBuilder,
    private messageService: MessageService) { }

  mobilisers = [];
  addMobiliserForm: FormGroup;
  submitted = false;


  ngOnInit(): void {

    this.getAllMobilisers();

    this.addMobiliserForm = this.formBuilder.group({
      cen_id: ['', Validators.required],
      mob_email: ['', [Validators.required]],
      mob_id: ['', [Validators.required]],
      mob_name: ['', [Validators.required]],
      mob_pass: ['', [Validators.required]],
      mob_pno: ['', [Validators.required]],
      op_id :['', [Validators.required]]
    })

  }

  getAllMobilisers()
  {
    this.mobilisers = this.httpService.getAllMobilisers();
    // console.log(this.mobilisers);
  }

  gotoMobiliser(id)
  {
    console.log(id);
    this.httpService.mob_id = id;
    this.router.navigateByUrl('/mobiliser-dashboard');
  }

  get f() { return this.addMobiliserForm.controls; }

  onSubmit() {

    this.submitted = true;
    if (this.addMobiliserForm.invalid) {
      return;
    }

    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.addMobiliserForm.value, null, 4));
    let payload = { "cen_id": null, "mob_email": null,"mob_pno":null ,"mob_id": null, "mob_pass": null, "mob_name": null,"op_id":null };
    payload.cen_id = this.addMobiliserForm.value.cen_id;
    payload.mob_email = this.addMobiliserForm.value.mob_email;
    payload.mob_id = this.addMobiliserForm.value.mob_id;
    payload.mob_pass = this.addMobiliserForm.value.mob_pass;
    payload.mob_name = this.addMobiliserForm.value.mob_name;
    payload.op_id = this.addMobiliserForm.value.op_id;
    payload.mob_pno = this.addMobiliserForm.value.pno;


    //api call to add mobiliser

    this.mobilisers = this.httpService.addMobiliser(payload);


    this.messageService.add({ severity: 'success', summary: 'Successful', detail: "Item added Successfully" });
    // $('#exampleModalCenter').modal('hide');


  }

  onReset() {
    this.submitted = false;
    this.addMobiliserForm.reset();
  }


}
